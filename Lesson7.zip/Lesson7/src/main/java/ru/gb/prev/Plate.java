package ru.gb.prev;

public class Plate {
    private final int capacity = 15;
    private int size = capacity;

    public boolean decrease(int request) {
        if (request <= size) {
            size -= request;
            return true;
        }
        return false;
    }

    public void add() {
        size = capacity;
    }

    public void add(int income) {
        int tmpSize = income + size;

        if (tmpSize >= capacity) {
            size = capacity;
        } else {
            size = tmpSize;
        }
    }

    @Override
    public String toString() {
        return "Plate{" +
                "capacity=" + capacity +
                ", size=" + size +
                '}';
    }
}
